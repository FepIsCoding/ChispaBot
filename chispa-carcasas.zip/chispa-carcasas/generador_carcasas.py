# Generador de carcasas Chispa. Medidas en mm. Cambiá los numeros de abajo y corré:  python3 generador_carcasas.py
import numpy as np, trimesh as tm
def B(x0,y0,z0,x1,y1,z1):
    m=tm.creation.box(extents=[x1-x0,y1-y0,z1-z0]); m.apply_translation([(x0+x1)/2,(y0+y1)/2,(z0+z1)/2]); return m
def CZ(x,y,r,z0=-1,z1=60):
    m=tm.creation.cylinder(radius=r,height=z1-z0,sections=24); m.apply_translation([x,y,(z0+z1)/2]); return m
def CX(y,z,r,x0,x1):
    m=tm.creation.cylinder(radius=r,height=x1-x0,sections=24)
    m.apply_transform(tm.transformations.rotation_matrix(np.pi/2,[0,1,0])); m.apply_translation([(x0+x1)/2,y,z]); return m
def sub(a,cuts): return tm.boolean.difference([a]+cuts,engine='manifold')
def add(ms): return tm.boolean.union(ms,engine='manifold')
def shell(W,H,D,t): return sub(B(0,0,0,W,H,D),[B(t,t,t,W-t,H-t,D+1)])
def lid(W,H,t,lip=3,gap=.2,wall=1.6):
    ring=sub(B(t+gap,t+gap,t,W-t-gap,H-t-gap,t+lip),[B(t+gap+wall,t+gap+wall,t-1,W-t-gap-wall,H-t-gap-wall,t+lip+1)])
    return add([B(0,0,0,W,H,t),ring])
def desk():
    W=H=74;D=36;t=2.4
    cuts=[B(W/2-14,32,-1,W/2+14,60,t+1),CZ(W/2,68,1,-1,t+1),B(W/2-5,-1,10,W/2+5,t+1,14)]
    cuts+=[CZ(W/2-12+6*i,10+6*j,1.25,-1,t+1) for i in range(5) for j in range(3)]
    return sub(shell(W,H,D,t),cuts), lid(W,H,t)
def pocket(pro=False):
    W=48;H=56;D=16;t=2
    body=add([shell(W,H,D,t),B(W/2-8,H-1,0,W/2+8,H+10,4)])
    cuts=[B(W/2-14,20,-1,W/2+14,48,t+1),B(W/2-5,-1,6,W/2+5,t+1,9.6),CZ(W/2,H+5.5,2.8,-1,6)]
    if pro: cuts.append(CX(28,D/2,2.6,W-t-1,W+1))
    return sub(body,cuts), lid(W,H,t,lip=2.5)
if __name__=="__main__":
    out={}
    df,db=desk(); out['chispa_desk_frente']=df; out['chispa_desk_tapa']=db
    pf,pb=pocket(); out['chispa_pocket_frente']=pf; out['chispa_pocket_tapa']=pb
    pp,_=pocket(True); out['chispa_pocket_pro_frente']=pp
    for n,m in out.items():
        m.export(n+'.stl'); print(n,m.is_watertight,m.bounds[1].round(1).tolist())
